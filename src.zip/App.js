import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Movie from './Movie'

const movieTitles = [
  "Matrix1", "Matrix2", "Matrix3", "Matrix4"
];

const moviceImages = [
  "https://www.qwaym.com/wp-content/uploads/2018/04/slave-to-the-matrix-exit.jpg",
  "https://cdn.movieweb.com/img.news.tops/NE5G2UgR0OYK96_2_b/Matrix-Reboot-Production-Warner-Bros-Studio.jpg",
  "https://cdn.empireonline.com/jpg/70/0/0/640/480/aspectfit/0/0/0/0/0/0/c/articles/58c8989331e02c7e3baf82ee/neo-matrix-keanu-reeves.jpg",
  "https://themerkle.com/wp-content/uploads/Matrix.png"
];

class App extends Component {

  state = {}

  componentDidMount() {
    this._getMovies()
  }

  _renderMovies = () => {
    const movies = this.state.movies.map(movie => {
      return <Movie
        title={movie.title}
        poster={movie.large_cover_image}
        key={movie.id}
        genres={movie.genres}
        synopsis={movie.synopsis}
      />
    })
    return movies
  }

  _getMovies = async () => {
    const movies = await this._callApi()
    this.setState({
      movies
    })
  }

  _callApi = () => {
    return fetch("http://localhost:3000/movies.json")
    .then(porto => porto.json())
    .then(json => json.data.movies)
    .catch(err => console.log(err))
  }

  render() {
    return (
      <div className="App">
        {this.state.movies ? this._renderMovies() : 'Loading'}
      </div>
    );
  }
}

export default App;
